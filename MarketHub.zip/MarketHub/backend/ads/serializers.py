from rest_framework import serializers
from .models import Ad, Category

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name']

class AdSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)
    
    class Meta:
        model = Ad
        fields = ['id', 'title', 'price', 'description', 'category']