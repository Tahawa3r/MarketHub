from django.urls import path
from .views import (
    ConversationListView,
    MessageListView,
    MarkMessagesAsReadView
)

urlpatterns = [
    path('conversations/', ConversationListView.as_view(), name='conversation-list'),
    path('conversations/<int:conversation_id>/messages/', MessageListView.as_view(), name='message-list'),
    path('conversations/<int:conversation_id>/mark-read/', MarkMessagesAsReadView.as_view(), name='mark-read'),
]