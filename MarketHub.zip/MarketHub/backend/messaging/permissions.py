from rest_framework import permissions

class IsParticipant(permissions.BasePermission):
    def has_permission(self, request, view):
        conversation_id = view.kwargs.get('conversation_id')
        if not conversation_id:
            return True
        return request.user.conversations.filter(id=conversation_id).exists()

    def has_object_permission(self, request, view, obj):
        return request.user in obj.conversation.participants.all()