from django.shortcuts import render
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import Conversation, Message
from .serializers import ConversationSerializer, MessageSerializer
from core.permissions import IsParticipant

class ConversationListView(generics.ListCreateAPIView):
    serializer_class = ConversationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return self.request.user.conversations.all()

    def perform_create(self, serializer):
        ad = serializer.validated_data['ad']
        participants = {self.request.user, ad.vendor}
        conversation, created = Conversation.objects.get_or_create(ad=ad)
        conversation.participants.add(*participants)
        serializer.instance = conversation

class MessageListView(generics.ListCreateAPIView):
    serializer_class = MessageSerializer
    permission_classes = [permissions.IsAuthenticated, IsParticipant]

    def get_queryset(self):
        conversation_id = self.kwargs['conversation_id']
        return Message.objects.filter(conversation_id=conversation_id)

    def perform_create(self, serializer):
        conversation = Conversation.objects.get(id=self.kwargs['conversation_id'])
        serializer.save(
            conversation=conversation,
            sender=self.request.user
        )

class MarkMessagesAsReadView(generics.GenericAPIView):
    permission_classes = [permissions.IsAuthenticated, IsParticipant]

    def post(self, request, conversation_id):
        Message.objects.filter(
            conversation_id=conversation_id
        ).exclude(
            sender=request.user
        ).update(is_read=True)
        return Response(status=status.HTTP_200_OK)